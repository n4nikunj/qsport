<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Game; 

class SportsController extends Controller
{
    /**
     * Get Sports List
     *
     * @return [Json] game object
     */
	
    public function list()
    {
		$game = Game::where('status', 'active')->get();
		if (!$game) {
			return response()->json([
			"success"=> "0",
				"status"=> "404",
				'message' => trans('games.empty')
			], 404);
		}
        return response()->json([
			"success"=> "1",
			"status"=> "200",
			"message"=> "Data Found",
			"data"=> $game],200);
    }
}
